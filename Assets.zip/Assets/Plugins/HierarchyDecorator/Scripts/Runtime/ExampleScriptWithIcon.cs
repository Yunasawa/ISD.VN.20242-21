﻿using UnityEngine;

namespace HierarchyDecorator
{
    public class ExampleScriptWithIcon : MonoBehaviour
    {

    }
}