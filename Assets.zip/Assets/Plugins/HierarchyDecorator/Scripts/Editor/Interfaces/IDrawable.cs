﻿namespace HierarchyDecorator
{
    public interface IDrawable
    {
        void OnDraw();
    }
}
